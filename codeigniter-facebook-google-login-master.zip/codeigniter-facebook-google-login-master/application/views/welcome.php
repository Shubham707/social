<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>codeigniter Facebook Google Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta http-equiv="Content-Language" content="en-us"/>
<meta http-equiv="Content-Style-Type" content="text/css"/>
<meta http-equiv="imagetoolbar" content="no"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link href="/css/main.css" media="all" rel="stylesheet" type="text/css"/>
</head>
<body>
<div id="wrapper">
	<div class="slim container">


		<div class="row">
			<div class="box01">

<div class="module_profile_box">
		<div class="box">
		<div class="img">
			<img class="profile" src="<?php echo $image; ?>" style="width:90px;" />

		</div>
		<div class="content">
			<div style="font-size:17px;font-weight:bold;color:black;"><?php echo $firstname." ".$lastname;?></div>
			<div style="font-size:13px;margin-bottom:10px;">New Member</div>
			<div style="font-size:12px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer pharetra adipiscing purus, sit amet viverra libero fringilla quis. Etiam semper placerat adipiscing.</div>
		</div>
	</div>

	<div class=clearfix></div>

	<div style="margin:20px 0 0 350px;">
		<a href=/auth/logout/><button type="button" id="loginBtn" class="nice radius button white">Logout</button></a>
	</div>

</div>


</div>
</div>



	</div>
</div>


</body>
</html>	