<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Facebook API
|--------------------------------------------------------------------------
*/
$config['facebook_id'] = '508943389164156';
$config['facebook_secret'] = 'f64b2d5281d88138104d49503173a3c4';


/*
|--------------------------------------------------------------------------
| Google API
|--------------------------------------------------------------------------
*/
$config['google_id'] = '739500193408-2ils01tmog5tis9tjelqebi587e6i4sr.apps.googleusercontent.com';
$config['google_secret'] = '3kPeoVM0P0bSw_y2Z0SwHq1t';



/* End of file oauth2.php */
/* Location: ./application/config/oauth2.php */